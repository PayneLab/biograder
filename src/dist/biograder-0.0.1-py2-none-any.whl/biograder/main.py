def main():
    #hw18 = Homework18()
    #print(hw18.submit("TEST2", 2, 12))
    #testString = "HELLO"


    #Homework18.submit(b'HELLO')
        pass

if __name__ == "__main__":
    main()

