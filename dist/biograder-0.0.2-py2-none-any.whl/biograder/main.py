from biograder.Homework18 import Homework18
from biograder.Parser import Parser


def main():
    parser = Parser()

    parser("HW18.txt")



if __name__ == "__main__":
    main()
